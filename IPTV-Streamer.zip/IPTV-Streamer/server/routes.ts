import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import fetch from "node-fetch";

// Helper to make calls to Xtream Codes API
async function callXtreamApi(config: any, action: string, params: Record<string, any> = {}) {
  const baseUrl = `${config.host}/player_api.php`;
  const url = new URL(baseUrl);
  url.searchParams.append("username", config.username);
  url.searchParams.append("password", config.password);
  url.searchParams.append("action", action);
  
  Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));

  const response = await fetch(url.toString());
  if (!response.ok) {
    throw new Error(`Xtream API Error: ${response.statusText}`);
  }
  return await response.json();
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Setup Replit Auth first
  await setupAuth(app);
  registerAuthRoutes(app);

  // === ADMIN / CONFIG ROUTES ===
  
  app.get(api.iptv.listConfigs.path, async (req, res) => {
    // TODO: Add Auth check
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const configs = await storage.getConfigs();
    res.json(configs);
  });

  app.post(api.iptv.createConfig.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    try {
      const input = api.iptv.createConfig.input.parse(req.body);
      const config = await storage.createConfig(input);
      res.status(201).json(config);
    } catch (err) {
       if (err instanceof z.ZodError) return res.status(400).json({ message: err.message });
       res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.put(api.iptv.updateConfig.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    try {
      const input = api.iptv.updateConfig.input.parse(req.body);
      const updated = await storage.updateConfig(Number(req.params.id), input);
      res.json(updated);
    } catch (err) {
       res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.delete(api.iptv.deleteConfig.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    await storage.deleteConfig(Number(req.params.id));
    res.status(204).send();
  });

  // === PROXY ROUTES FOR PLAYER ===
  // These routes hide the Xtream credentials from the frontend

  app.get(api.iptv.getCategories.path, async (req, res) => {
    const type = req.params.type; // 'live', 'vod', 'series'
    const config = await storage.getActiveConfig();
    
    if (!config) {
      return res.status(404).json({ message: "No active IPTV configuration found." });
    }

    try {
      let action = "";
      if (type === 'live') action = "get_live_categories";
      else if (type === 'vod') action = "get_vod_categories";
      else if (type === 'series') action = "get_series_categories";
      
      const data = await callXtreamApi(config, action);
      res.json(data);
    } catch (error) {
      console.error("Xtream API Error:", error);
      res.status(500).json({ message: "Failed to fetch categories from IPTV server." });
    }
  });

  app.get(api.iptv.getStreams.path, async (req, res) => {
    const type = req.params.type;
    const categoryId = req.params.categoryId;
    const config = await storage.getActiveConfig();

    if (!config) {
      return res.status(404).json({ message: "No active IPTV configuration found." });
    }

    try {
      let action = "";
      if (type === 'live') action = "get_live_streams";
      else if (type === 'vod') action = "get_vod_streams";
      else if (type === 'series') action = "get_series"; // Series endpoint is slightly different usually

      const data = await callXtreamApi(config, action, { category_id: categoryId });
      res.json(data);
    } catch (error) {
      console.error("Xtream API Error:", error);
      res.status(500).json({ message: "Failed to fetch streams." });
    }
  });

  // === IPTV LOGIN (FOR END USERS) ===
  app.post("/api/iptv/login", async (req, res) => {
    try {
      const { hostId, username, password } = req.body;
      const config = await storage.getConfig(Number(hostId));
      if (!config) return res.status(404).json({ message: "Host not found" });

      // Validate against host
      const loginData = await callXtreamApi(config, "login", { username, password }) as any;
      if (loginData?.user_info?.auth === 1) {
        // Successful IPTV Auth
        // Store in session (optional, but good for persistence)
        (req.session as any).iptv = { hostId, username, password };
        res.json({ success: true, info: loginData.user_info });
      } else {
        res.status(401).json({ message: "Invalid IPTV credentials" });
      }
    } catch (err) {
      res.status(500).json({ message: "Failed to connect to IPTV server" });
    }
  });
  // Seed Data (if empty)
  const existingConfigs = await storage.getConfigs();
  if (existingConfigs.length === 0) {
    console.log("Seeding example IPTV config...");
    // Add a dummy config so UI isn't empty (user will need to edit this)
    await storage.createConfig({
      name: "Smarters Server",
      host: "http://smarters.info",
      username: "demo_user",
      password: "demo_password",
      isActive: true
    });
  }

  return httpServer;
}
