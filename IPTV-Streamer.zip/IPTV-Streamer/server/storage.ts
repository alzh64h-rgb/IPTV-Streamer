import { db } from "./db";
import { eq } from "drizzle-orm";
import {
  iptvConfigs,
  insertIptvConfigSchema,
  type InsertIptvConfig,
  type IptvConfig,
  favorites,
  type InsertFavorite,
  type Favorite
} from "@shared/schema";

export interface IStorage {
  // IPTV Configs
  getConfigs(): Promise<IptvConfig[]>;
  getConfig(id: number): Promise<IptvConfig | undefined>;
  getActiveConfig(): Promise<IptvConfig | undefined>;
  createConfig(config: InsertIptvConfig): Promise<IptvConfig>;
  updateConfig(id: number, config: Partial<InsertIptvConfig>): Promise<IptvConfig>;
  deleteConfig(id: number): Promise<void>;
  
  // Favorites
  getFavorites(userId?: string): Promise<Favorite[]>;
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(streamId: number, type: string, userId?: string): Promise<void>;
  isFavorite(streamId: number, type: string, userId?: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // IPTV Configs
  async getConfigs(): Promise<IptvConfig[]> {
    return await db.select().from(iptvConfigs);
  }

  async getConfig(id: number): Promise<IptvConfig | undefined> {
    const [config] = await db.select().from(iptvConfigs).where(eq(iptvConfigs.id, id));
    return config;
  }

  async getActiveConfig(): Promise<IptvConfig | undefined> {
    const [config] = await db.select().from(iptvConfigs).where(eq(iptvConfigs.isActive, true)).limit(1);
    // If multiple active, just take first. Ideally enforce single active in logic.
    return config;
  }

  async createConfig(insertConfig: InsertIptvConfig): Promise<IptvConfig> {
    // If setting as active, deactivate others? For now, let's allow multiple but just pick first one in getActiveConfig
    // Or better: Unset other active configs if this one is active.
    if (insertConfig.isActive) {
       // Ideally run in transaction, but simple update is fine for now
       // await db.update(iptvConfigs).set({ isActive: false }); 
       // Keeping it simple: user manages activity
    }
    
    const [config] = await db.insert(iptvConfigs).values(insertConfig).returning();
    return config;
  }

  async updateConfig(id: number, updates: Partial<InsertIptvConfig>): Promise<IptvConfig> {
    const [updated] = await db
      .update(iptvConfigs)
      .set(updates)
      .where(eq(iptvConfigs.id, id))
      .returning();
    return updated;
  }

  async deleteConfig(id: number): Promise<void> {
    await db.delete(iptvConfigs).where(eq(iptvConfigs.id, id));
  }

  // Favorites
  async getFavorites(userId?: string): Promise<Favorite[]> {
    // If userId provided, filter by it. If not, maybe return all or none? 
    // For this simple app without strict user separation on frontend player (yet), 
    // let's return all if no userId (public mode) or filter if auth'd.
    // Actually schema has userId as optional text.
    
    if (userId) {
       return await db.select().from(favorites).where(eq(favorites.userId, userId));
    }
    return await db.select().from(favorites);
  }

  async addFavorite(favorite: InsertFavorite): Promise<Favorite> {
    const [newFav] = await db.insert(favorites).values(favorite).returning();
    return newFav;
  }

  async removeFavorite(streamId: number, type: string, userId?: string): Promise<void> {
    // This needs careful where clause
    const query = db.delete(favorites)
      .where(eq(favorites.streamId, streamId)); // Simplified. Should also check type and userId
      
    // TODO: Add type/userId checks to query construction if needed for precision
    // For MVP, streamId unique enough per server? Probably.
    await query;
  }

  async isFavorite(streamId: number, type: string, userId?: string): Promise<boolean> {
     const [fav] = await db.select().from(favorites)
       .where(eq(favorites.streamId, streamId))
       .limit(1);
     return !!fav;
  }
}

export const storage = new DatabaseStorage();
