import { cn } from "@/lib/utils";

interface Category {
  category_id: string;
  category_name: string;
}

interface CategoryListProps {
  categories: Category[];
  selectedId: string | undefined;
  onSelect: (id: string) => void;
  isLoading?: boolean;
}

export function CategoryList({ categories, selectedId, onSelect, isLoading }: CategoryListProps) {
  if (isLoading) {
    return (
      <div className="space-y-2 p-4">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="h-10 w-full animate-pulse rounded-lg bg-secondary/50" />
        ))}
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto p-4 space-y-1 hide-scrollbar">
      <div className="mb-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-2">Categories</h3>
      </div>
      
      {/* "All" Category Option could go here */}
      
      {categories?.map((cat) => (
        <button
          key={cat.category_id}
          onClick={() => onSelect(cat.category_id)}
          className={cn(
            "w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 truncate",
            selectedId === cat.category_id
              ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
              : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
          )}
        >
          {cat.category_name}
        </button>
      ))}
      
      {categories?.length === 0 && (
        <div className="text-center py-8 text-muted-foreground text-sm">
          No categories found.
        </div>
      )}
    </div>
  );
}
