import { Play, Heart, Info } from "lucide-react";
import { cn } from "@/lib/utils";
import { useFavorites, useToggleFavorite } from "@/hooks/use-favorites";

interface ContentItem {
  num: number;
  name: string;
  stream_id: number;
  stream_icon?: string;
  stream_type?: string;
  rating?: string;
  added?: string;
}

interface ContentGridProps {
  items: ContentItem[];
  type: 'live' | 'vod' | 'series';
  onPlay: (item: ContentItem) => void;
  isLoading?: boolean;
}

export function ContentGrid({ items, type, onPlay, isLoading }: ContentGridProps) {
  const { data: favorites } = useFavorites();
  const toggleFav = useToggleFavorite();

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 p-6">
        {[...Array(12)].map((_, i) => (
          <div key={i} className="aspect-[2/3] animate-pulse rounded-xl bg-secondary/50" />
        ))}
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="flex h-full flex-col items-center justify-center p-8 text-center text-muted-foreground">
        <div className="rounded-full bg-secondary/50 p-4 mb-4">
          <Info className="h-8 w-8" />
        </div>
        <p className="text-lg font-medium">No content found in this category</p>
      </div>
    );
  }

  const isLive = type === 'live';

  return (
    <div className={cn(
      "grid gap-4 p-6 pb-20",
      isLive 
        ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" 
        : "grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6"
    )}>
      {items.map((item) => {
        const isFav = favorites?.some(f => f.streamId === item.stream_id && f.type === type);
        
        return (
          <div 
            key={item.stream_id}
            className={cn(
              "group relative overflow-hidden rounded-xl bg-card border border-border/50",
              isLive ? "aspect-video" : "aspect-[2/3]",
              "movie-card-hover"
            )}
          >
            {/* Image/Thumbnail */}
            {item.stream_icon ? (
              <img 
                src={item.stream_icon} 
                alt={item.name}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://placehold.co/400x600/1e293b/475569?text=No+Image';
                }}
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-secondary/50 text-muted-foreground p-4 text-center">
                <span className="text-xs">{item.name}</span>
              </div>
            )}

            {/* Overlay Gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-60 transition-opacity duration-300 group-hover:opacity-80" />

            {/* Content Info (Always visible at bottom) */}
            <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
              <h4 className="text-sm font-semibold text-white line-clamp-2 leading-tight mb-1">{item.name}</h4>
              <div className="flex items-center justify-between opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-75">
                <span className="text-xs text-gray-300 capitalize">{type}</span>
              </div>
            </div>

            {/* Actions Overlay (Center) */}
            <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity duration-300 group-hover:opacity-100">
              <div className="flex gap-2 transform scale-90 group-hover:scale-100 transition-transform duration-300">
                <button
                  onClick={() => onPlay(item)}
                  className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-white shadow-lg shadow-primary/40 hover:scale-110 hover:bg-primary/90 transition-all"
                >
                  <Play className="h-5 w-5 fill-current ml-0.5" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFav.mutate({
                      streamId: item.stream_id,
                      name: item.name,
                      type: type,
                      posterUrl: item.stream_icon,
                    });
                  }}
                  className={cn(
                    "flex h-12 w-12 items-center justify-center rounded-full bg-black/60 text-white backdrop-blur-md hover:scale-110 transition-all",
                    isFav ? "text-red-500" : "hover:text-red-500"
                  )}
                >
                  <Heart className={cn("h-5 w-5", isFav && "fill-current")} />
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
