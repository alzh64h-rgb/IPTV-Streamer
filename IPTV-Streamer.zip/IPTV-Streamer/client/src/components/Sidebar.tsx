import { Link, useLocation } from "wouter";
import { Tv, Film, MonitorPlay, Heart, Settings, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

const navItems = [
  { href: "/", label: "Live TV", icon: Tv },
  { href: "/movies", label: "Movies", icon: Film },
  { href: "/series", label: "Series", icon: MonitorPlay },
  { href: "/favorites", label: "Favorites", icon: Heart },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-20 flex-col justify-between border-r border-border bg-card/95 backdrop-blur-sm lg:flex lg:w-64 transition-all duration-300">
      <div className="flex flex-col h-full">
        <div className="flex h-16 items-center justify-center border-b border-border px-4 lg:justify-start">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Tv className="h-5 w-5" />
            </div>
            <span className="hidden text-xl font-bold tracking-tight text-foreground lg:block font-display">
              StreamHub
            </span>
          </div>
        </div>

        <nav className="flex-1 space-y-2 p-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href} className={cn(
                  "group flex items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium transition-all duration-200",
                  isActive 
                    ? "bg-primary text-primary-foreground shadow-md shadow-primary/25" 
                    : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
                )}>
                  <Icon className={cn("h-5 w-5", isActive ? "text-primary-foreground" : "text-muted-foreground group-hover:text-foreground")} />
                  <span className="hidden lg:block">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-border p-4">
          {user ? (
            <div className="flex items-center justify-between rounded-lg bg-secondary/50 p-3">
              <div className="flex items-center gap-3 overflow-hidden">
                {user.profileImageUrl && (
                  <img src={user.profileImageUrl} alt="User" className="h-8 w-8 rounded-full" />
                )}
                <div className="hidden flex-col lg:flex">
                  <span className="truncate text-sm font-medium">{user.firstName || 'Admin'}</span>
                  <span className="truncate text-xs text-muted-foreground">{user.email || 'Logged In'}</span>
                </div>
              </div>
              <button 
                onClick={() => logout()}
                className="rounded-md p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"
                title="Logout"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
             <div className="hidden lg:block text-xs text-center text-muted-foreground p-2">
               Admin access required for Settings
             </div>
          )}
        </div>
      </div>
    </aside>
  );
}
