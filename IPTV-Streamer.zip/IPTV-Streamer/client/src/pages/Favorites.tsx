import { useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { ContentGrid } from "@/components/ContentGrid";
import { VideoPlayer } from "@/components/VideoPlayer";
import { useFavorites } from "@/hooks/use-favorites";
import { useIptvConfigs } from "@/hooks/use-iptv";
import { Heart } from "lucide-react";

export default function Favorites() {
  const { data: favorites, isLoading } = useFavorites();
  const { data: configs } = useIptvConfigs();
  const [activeItem, setActiveItem] = useState<any>(null);

  const activeConfig = configs?.find(c => c.isActive);

  // Transform Favorites DB shape to ContentItem shape for Grid
  const mappedItems = favorites?.map(fav => ({
    num: 0,
    name: fav.name,
    stream_id: fav.streamId,
    stream_icon: fav.posterUrl || undefined,
    stream_type: fav.type,
    // Add extra prop to distinguish types if needed
    originalType: fav.type 
  })) || [];

  const handlePlay = (item: any) => {
    if (!activeConfig) return;
    const { host, username, password } = activeConfig;
    let url = "";

    if (item.originalType === 'live') {
      url = `${host}/${username}/${password}/${item.stream_id}`;
    } else if (item.originalType === 'vod') {
      url = `${host}/movie/${username}/${password}/${item.stream_id}.mp4`; // simplified assumption
    } else {
      // Series not playable directly yet
      return;
    }

    setActiveItem({
      ...item,
      url
    });
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar />
      <main className="flex-1 ml-0 lg:ml-20 lg:pl-0 flex flex-col h-full transition-all duration-300">
        <div className="sticky top-0 z-30 p-6 bg-background/95 backdrop-blur border-b border-border/40">
          <h2 className="text-2xl font-bold flex items-center gap-3">
            <Heart className="text-red-500 fill-current h-6 w-6" /> Your Favorites
          </h2>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {isLoading ? (
            <div className="p-8">Loading favorites...</div>
          ) : mappedItems.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center p-8 text-center text-muted-foreground animate-in fade-in zoom-in-95 duration-500">
              <div className="h-24 w-24 rounded-full bg-secondary/50 flex items-center justify-center mb-6">
                <Heart className="h-10 w-10 opacity-50" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-2">No Favorites Yet</h3>
              <p>Mark channels and movies as favorites to see them here.</p>
            </div>
          ) : (
            <ContentGrid 
              items={mappedItems}
              type="live" // Just passes type for styling; logic handled inside
              onPlay={handlePlay}
            />
          )}
        </div>
      </main>

      {activeItem && (
        <VideoPlayer 
          url={activeItem.url}
          title={activeItem.name}
          onClose={() => setActiveItem(null)}
        />
      )}
    </div>
  );
}
