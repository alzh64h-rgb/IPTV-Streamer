import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { Loader2, PlayCircle, Tv } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function Home() {
  const [, setLocation] = useLocation();
  const [session, setSession] = useState<any>(null);

  useEffect(() => {
    const saved = localStorage.getItem("iptv_session");
    if (!saved) {
      setLocation("/login");
    } else {
      setSession(JSON.parse(saved));
    }
  }, [setLocation]);

  const { data: categories, isLoading } = useQuery<any[]>({
    queryKey: [buildUrl(api.iptv.getCategories.path, { type: "live" })],
    enabled: !!session,
  });

  if (!session || isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto p-6 space-y-8 bg-background">
      <section className="relative h-[400px] rounded-xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent z-10" />
        <img 
          src="https://images.unsplash.com/photo-1593784991095-a205069470b6?q=80&w=2070&auto=format&fit=crop" 
          className="absolute inset-0 w-full h-full object-cover"
          alt="Hero"
        />
        <div className="relative z-20 h-full flex flex-col justify-center p-12 space-y-4 max-w-2xl">
          <div className="flex items-center gap-2 text-primary font-bold">
            <Tv className="h-5 w-5" />
            <span>LIVE TV NOW</span>
          </div>
          <h1 className="text-6xl font-bold leading-tight">Your Complete Entertainment Hub</h1>
          <p className="text-xl text-gray-300">Experience seamless streaming of thousands of channels, movies, and series at your fingertips.</p>
        </div>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-bold">Live Categories</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {categories?.map((cat) => (
            <Card key={cat.category_id} className="hover-elevate cursor-pointer overflow-hidden border-none bg-card/50 transition-all hover:bg-card">
              <CardContent className="p-4 flex flex-col items-center justify-center aspect-video text-center space-y-2">
                <PlayCircle className="h-8 w-8 text-primary" />
                <span className="font-medium line-clamp-2">{cat.category_name}</span>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
