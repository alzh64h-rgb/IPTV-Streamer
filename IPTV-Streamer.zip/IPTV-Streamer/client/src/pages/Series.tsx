import { useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { CategoryList } from "@/components/CategoryList";
import { ContentGrid } from "@/components/ContentGrid";
import { useCategories, useStreams } from "@/hooks/use-iptv";
import { MonitorPlay, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

export default function Series() {
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const { data: categories, isLoading: catLoading } = useCategories('series');
  const { data: streams, isLoading: streamLoading } = useStreams('series', selectedCategory);

  const filteredStreams = streams?.filter((s: any) => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const handlePlay = (stream: any) => {
    // Series play is complex (Seasons -> Episodes). 
    // For MVP, just showing toast that detail view would be next.
    toast({
      title: "Coming Soon",
      description: `Series detail view for "${stream.name}" is under development.`,
    });
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar />
      <main className="flex-1 ml-0 lg:ml-20 lg:pl-0 flex flex-col h-full lg:flex-row transition-all duration-300">
        <div className="hidden md:flex w-64 flex-col border-r border-border bg-card/50 h-full">
          <div className="p-4 border-b border-border/50">
            <h2 className="text-lg font-bold flex items-center gap-2">
              <MonitorPlay className="text-primary h-5 w-5" /> TV Series
            </h2>
          </div>
          <CategoryList 
            categories={categories || []}
            selectedId={selectedCategory}
            onSelect={setSelectedCategory}
            isLoading={catLoading}
          />
        </div>

        <div className="flex-1 flex flex-col h-full overflow-hidden relative">
          <div className="sticky top-0 z-30 flex items-center justify-between p-6 bg-background/95 backdrop-blur border-b border-border/40">
            <div className="md:hidden"><h2 className="text-xl font-bold">Series</h2></div>
            <div className="relative w-full max-w-md ml-auto">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search series..."
                className="pl-10 bg-secondary/50 border-transparent focus:bg-background focus:border-primary transition-all rounded-xl"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar">
            {!selectedCategory ? (
              <div className="flex h-full flex-col items-center justify-center p-8 text-center text-muted-foreground animate-in fade-in zoom-in-95 duration-500">
                <div className="h-24 w-24 rounded-full bg-secondary/50 flex items-center justify-center mb-6">
                  <MonitorPlay className="h-10 w-10 opacity-50" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-2">Select a Genre</h3>
                <p>Binge-worthy TV shows await.</p>
              </div>
            ) : (
              <ContentGrid 
                items={filteredStreams}
                type="series"
                onPlay={handlePlay}
                isLoading={streamLoading}
              />
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
