import { useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { CategoryList } from "@/components/CategoryList";
import { ContentGrid } from "@/components/ContentGrid";
import { VideoPlayer } from "@/components/VideoPlayer";
import { useCategories, useStreams, useIptvConfigs } from "@/hooks/use-iptv";
import { Tv, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function LiveTV() {
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeStream, setActiveStream] = useState<any>(null);

  // 1. Get Config to know base URL (simple logic: take first active config)
  const { data: configs } = useIptvConfigs();
  const activeConfig = configs?.find(c => c.isActive);

  // 2. Data Fetching
  const { data: categories, isLoading: catLoading } = useCategories('live');
  const { data: streams, isLoading: streamLoading } = useStreams('live', selectedCategory);

  // 3. Filter Streams
  const filteredStreams = streams?.filter((s: any) => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const handlePlay = (stream: any) => {
    if (!activeConfig) return;
    // Construct Direct Stream URL
    // Format: http://host:port/username/password/streamId
    const { host, username, password } = activeConfig;
    const streamUrl = `${host}/${username}/${password}/${stream.stream_id}`;
    
    setActiveStream({
      ...stream,
      url: streamUrl
    });
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 ml-0 lg:ml-20 lg:pl-0 flex flex-col h-full lg:flex-row transition-all duration-300">
        
        {/* Categories Sidebar */}
        <div className="hidden md:flex w-64 flex-col border-r border-border bg-card/50 h-full">
          <div className="p-4 border-b border-border/50">
            <h2 className="text-lg font-bold flex items-center gap-2">
              <Tv className="text-primary h-5 w-5" /> Live Channels
            </h2>
          </div>
          <CategoryList 
            categories={categories || []}
            selectedId={selectedCategory}
            onSelect={setSelectedCategory}
            isLoading={catLoading}
          />
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col h-full overflow-hidden relative">
          {/* Header / Search */}
          <div className="sticky top-0 z-30 flex items-center justify-between p-6 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border/40">
            <div className="md:hidden">
              <h2 className="text-xl font-bold">Live TV</h2>
            </div>
            
            <div className="relative w-full max-w-md ml-auto">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search channels..."
                className="pl-10 bg-secondary/50 border-transparent focus:bg-background focus:border-primary transition-all rounded-xl"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          {/* Stream Grid */}
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            {!selectedCategory ? (
              <div className="flex h-full flex-col items-center justify-center p-8 text-center text-muted-foreground animate-in fade-in zoom-in-95 duration-500">
                <div className="h-24 w-24 rounded-full bg-secondary/50 flex items-center justify-center mb-6">
                  <Tv className="h-10 w-10 opacity-50" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-2">Select a Category</h3>
                <p className="max-w-xs mx-auto">Choose a channel category from the sidebar to start watching live TV.</p>
              </div>
            ) : (
              <ContentGrid 
                items={filteredStreams}
                type="live"
                onPlay={handlePlay}
                isLoading={streamLoading}
              />
            )}
          </div>
        </div>
      </main>

      {/* Video Player Overlay */}
      {activeStream && (
        <VideoPlayer 
          url={activeStream.url}
          title={activeStream.name}
          onClose={() => setActiveStream(null)}
        />
      )}
    </div>
  );
}
