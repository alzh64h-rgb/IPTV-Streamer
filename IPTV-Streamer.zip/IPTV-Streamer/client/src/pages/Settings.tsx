import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertIptvConfigSchema } from "@shared/schema";
import { type InsertIptvConfig } from "@shared/schema";
import { Sidebar } from "@/components/Sidebar";
import { useAuth } from "@/hooks/use-auth";
import { useIptvConfigs, useCreateIptvConfig, useDeleteIptvConfig } from "@/hooks/use-iptv";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Trash2, Server, CheckCircle2, ShieldAlert } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function Settings() {
  const { user, isAuthenticated } = useAuth();
  const { data: configs, isLoading } = useIptvConfigs();
  const createConfig = useCreateIptvConfig();
  const deleteConfig = useDeleteIptvConfig();
  const { toast } = useToast();

  const form = useForm<InsertIptvConfig>({
    resolver: zodResolver(insertIptvConfigSchema),
    defaultValues: {
      name: "",
      host: "",
      username: "",
      password: "",
      isActive: true,
    },
  });

  const onSubmit = (data: InsertIptvConfig) => {
    // Basic formatting cleanup
    if (data.host.endsWith('/')) data.host = data.host.slice(0, -1);
    if (!data.host.startsWith('http')) data.host = `http://${data.host}`;
    
    createConfig.mutate(data, {
      onSuccess: () => form.reset(),
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="flex h-screen bg-background text-foreground overflow-hidden">
        <Sidebar />
        <main className="flex-1 ml-0 lg:ml-20 flex items-center justify-center p-8">
          <Card className="w-full max-w-md border-border bg-card/50 backdrop-blur-sm">
            <CardHeader className="text-center">
              <div className="mx-auto bg-primary/20 p-4 rounded-full w-fit mb-4">
                <ShieldAlert className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Admin Access Required</CardTitle>
              <CardDescription>
                You must be logged in to manage IPTV server configurations.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center pb-8">
              <Button onClick={() => window.location.href = "/api/login"} size="lg" className="w-full max-w-xs font-semibold shadow-lg shadow-primary/25">
                Login with Replit
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar />
      <main className="flex-1 ml-0 lg:ml-20 lg:pl-0 p-8 overflow-y-auto custom-scrollbar">
        <div className="max-w-4xl mx-auto space-y-8">
          
          <div>
            <h1 className="text-3xl font-bold mb-2">Settings</h1>
            <p className="text-muted-foreground">Manage your IPTV connections and preferences.</p>
          </div>

          <div className="grid gap-8 lg:grid-cols-2">
            
            {/* Create Config Form */}
            <Card className="bg-card/50 backdrop-blur-sm border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Server className="h-5 w-5 text-primary" /> Add New Server
                </CardTitle>
                <CardDescription>Connect to an Xtream Codes IPTV provider.</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Server Name</FormLabel>
                          <FormControl>
                            <Input placeholder="My IPTV" {...field} className="bg-secondary/50 border-border" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="host"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Host URL</FormLabel>
                          <FormControl>
                            <Input placeholder="http://example.com:8080" {...field} className="bg-secondary/50 border-border" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username</FormLabel>
                            <FormControl>
                              <Input placeholder="user123" {...field} className="bg-secondary/50 border-border" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="••••••" {...field} className="bg-secondary/50 border-border" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full mt-4 font-semibold shadow-lg shadow-primary/20"
                      disabled={createConfig.isPending}
                    >
                      {createConfig.isPending ? "Connecting..." : "Add Server"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            {/* Config List */}
            <div className="space-y-4">
              <h2 className="text-xl font-bold px-1">Connected Servers</h2>
              {isLoading ? (
                <div className="animate-pulse space-y-4">
                  {[1, 2].map(i => <div key={i} className="h-24 rounded-xl bg-card/50" />)}
                </div>
              ) : configs?.length === 0 ? (
                <Card className="bg-card/30 border-dashed border-border p-8 text-center text-muted-foreground">
                  <p>No servers configured yet.</p>
                </Card>
              ) : (
                configs?.map((config) => (
                  <Card key={config.id} className={cn("bg-card/50 backdrop-blur-sm border-border transition-all", config.isActive && "border-primary/50 ring-1 ring-primary/20")}>
                    <CardContent className="flex items-center justify-between p-6">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold">{config.name}</h3>
                          {config.isActive && (
                            <span className="flex h-2 w-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]" />
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground font-mono">{config.host}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {config.isActive ? (
                          <Button variant="ghost" size="sm" className="text-green-500 hover:text-green-400 hover:bg-green-500/10 cursor-default">
                            <CheckCircle2 className="h-4 w-4 mr-2" /> Active
                          </Button>
                        ) : (
                          <Button variant="outline" size="sm">Activate</Button>
                        )}
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                          onClick={() => {
                            if (confirm('Are you sure you want to delete this server?')) {
                              deleteConfig.mutate(config.id);
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}
