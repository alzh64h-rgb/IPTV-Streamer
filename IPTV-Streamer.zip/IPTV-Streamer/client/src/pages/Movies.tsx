import { useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { CategoryList } from "@/components/CategoryList";
import { ContentGrid } from "@/components/ContentGrid";
import { VideoPlayer } from "@/components/VideoPlayer";
import { useCategories, useStreams, useIptvConfigs } from "@/hooks/use-iptv";
import { Film, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function Movies() {
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeMovie, setActiveMovie] = useState<any>(null);

  const { data: configs } = useIptvConfigs();
  const activeConfig = configs?.find(c => c.isActive);

  const { data: categories, isLoading: catLoading } = useCategories('vod');
  const { data: streams, isLoading: streamLoading } = useStreams('vod', selectedCategory);

  const filteredStreams = streams?.filter((s: any) => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const handlePlay = (stream: any) => {
    if (!activeConfig) return;
    // VOD URL Format: http://host:port/movie/username/password/streamId.extension
    // Extension usually .mp4 or .mkv, Xtream API often handles auto-detect or defaults to mp4/mkv container
    // We'll try generic structure without extension or assume .mp4/mkv if needed. 
    // Xtream usually redirects /movie/u/p/id.mp4 correctly.
    const { host, username, password } = activeConfig;
    const streamUrl = `${host}/movie/${username}/${password}/${stream.stream_id}.${stream.container_extension || 'mp4'}`;
    
    setActiveMovie({
      ...stream,
      url: streamUrl
    });
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar />
      <main className="flex-1 ml-0 lg:ml-20 lg:pl-0 flex flex-col h-full lg:flex-row transition-all duration-300">
        <div className="hidden md:flex w-64 flex-col border-r border-border bg-card/50 h-full">
          <div className="p-4 border-b border-border/50">
            <h2 className="text-lg font-bold flex items-center gap-2">
              <Film className="text-primary h-5 w-5" /> Movies
            </h2>
          </div>
          <CategoryList 
            categories={categories || []}
            selectedId={selectedCategory}
            onSelect={setSelectedCategory}
            isLoading={catLoading}
          />
        </div>

        <div className="flex-1 flex flex-col h-full overflow-hidden relative">
          <div className="sticky top-0 z-30 flex items-center justify-between p-6 bg-background/95 backdrop-blur border-b border-border/40">
            <div className="md:hidden"><h2 className="text-xl font-bold">Movies</h2></div>
            <div className="relative w-full max-w-md ml-auto">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search movies..."
                className="pl-10 bg-secondary/50 border-transparent focus:bg-background focus:border-primary transition-all rounded-xl"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar">
            {!selectedCategory ? (
              <div className="flex h-full flex-col items-center justify-center p-8 text-center text-muted-foreground animate-in fade-in zoom-in-95 duration-500">
                <div className="h-24 w-24 rounded-full bg-secondary/50 flex items-center justify-center mb-6">
                  <Film className="h-10 w-10 opacity-50" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-2">Select a Genre</h3>
                <p>Browse your movie collection by selecting a category.</p>
              </div>
            ) : (
              <ContentGrid 
                items={filteredStreams}
                type="vod"
                onPlay={handlePlay}
                isLoading={streamLoading}
              />
            )}
          </div>
        </div>
      </main>

      {activeMovie && (
        <VideoPlayer 
          url={activeMovie.url}
          title={activeMovie.name}
          onClose={() => setActiveMovie(null)}
        />
      )}
    </div>
  );
}
