import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertIptvConfigSchema, type IptvConfig } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Plus, Trash2, Edit2 } from "lucide-react";

export default function Admin() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [editingId, setEditingId] = useState<number | null>(null);

  const { data: configs, isLoading: configsLoading } = useQuery<IptvConfig[]>({
    queryKey: [api.iptv.listConfigs.path],
    enabled: isAuthenticated,
  });

  const form = useForm({
    resolver: zodResolver(insertIptvConfigSchema),
    defaultValues: {
      name: "",
      host: "",
      username: "internal_admin", // Not used for end-user login
      password: "password",
      isActive: true,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", api.iptv.createConfig.path, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.iptv.listConfigs.path] });
      form.reset();
      toast({ title: "Success", description: "Host added successfully" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", buildUrl(api.iptv.deleteConfig.path, { id }));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.iptv.listConfigs.path] });
      toast({ title: "Success", description: "Host deleted" });
    },
  });

  if (authLoading) return <div className="flex h-screen items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>;

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center h-full space-y-4">
        <h1 className="text-2xl font-bold">Admin Access Required</h1>
        <Button onClick={() => window.location.href = "/api/login"}>Login with Replit</Button>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8 max-w-4xl mx-auto">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Admin Control Panel</h1>
        <div className="flex items-center gap-4">
           <span className="text-sm text-muted-foreground">Logged in as {user?.email}</span>
           <Button variant="outline" onClick={() => window.location.href = "/api/logout"}>Logout</Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Add New IPTV Host</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit((data) => createMutation.mutate(data))} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Host Name</FormLabel>
                      <FormControl><Input placeholder="e.g. My Server" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="host"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Host URL</FormLabel>
                      <FormControl><Input placeholder="http://smarters.info" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <Button type="submit" className="w-full" disabled={createMutation.isPending}>
                {createMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}
                Add Host
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Configured Hosts</h2>
        {configsLoading ? (
          <Loader2 className="h-8 w-8 animate-spin" />
        ) : (
          <div className="grid gap-4">
            {configs?.map((config) => (
              <Card key={config.id}>
                <CardContent className="flex items-center justify-between p-4">
                  <div>
                    <h3 className="font-bold">{config.name}</h3>
                    <p className="text-sm text-muted-foreground">{config.host}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="icon" onClick={() => deleteMutation.mutate(config.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
