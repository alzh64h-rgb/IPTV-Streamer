import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertIptvConfig } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

// === CONFIGS (ADMIN) ===

export function useIptvConfigs() {
  return useQuery({
    queryKey: [api.iptv.listConfigs.path],
    queryFn: async () => {
      const res = await fetch(api.iptv.listConfigs.path, { credentials: "include" });
      if (res.status === 401) throw new Error("Unauthorized");
      if (!res.ok) throw new Error("Failed to fetch configs");
      return api.iptv.listConfigs.responses[200].parse(await res.json());
    },
    retry: false,
  });
}

export function useCreateIptvConfig() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertIptvConfig) => {
      const res = await fetch(api.iptv.createConfig.path, {
        method: api.iptv.createConfig.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        if (res.status === 400) {
           const err = await res.json();
           throw new Error(err.message || "Validation failed");
        }
        if (res.status === 401) throw new Error("Unauthorized");
        throw new Error('Failed to create config');
      }
      return api.iptv.createConfig.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.iptv.listConfigs.path] });
      toast({ title: "Success", description: "IPTV Server added successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });
}

export function useUpdateIptvConfig() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & Partial<InsertIptvConfig>) => {
      const url = buildUrl(api.iptv.updateConfig.path, { id });
      const res = await fetch(url, {
        method: api.iptv.updateConfig.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
        credentials: "include",
      });
      if (!res.ok) throw new Error('Failed to update config');
      return api.iptv.updateConfig.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.iptv.listConfigs.path] });
      toast({ title: "Success", description: "Config updated successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });
}

export function useDeleteIptvConfig() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.iptv.deleteConfig.path, { id });
      const res = await fetch(url, { 
        method: api.iptv.deleteConfig.method,
        credentials: "include" 
      });
      if (!res.ok) throw new Error('Failed to delete config');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.iptv.listConfigs.path] });
      toast({ title: "Success", description: "Config deleted" });
    },
  });
}

// === PLAYER DATA ===

export function useCategories(type: 'live' | 'vod' | 'series') {
  return useQuery({
    queryKey: [api.iptv.getCategories.path, type],
    queryFn: async () => {
      const url = buildUrl(api.iptv.getCategories.path, { type });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch categories");
      return await res.json(); // Returning any[] as per schema
    },
    staleTime: 1000 * 60 * 5, // 5 mins
  });
}

export function useStreams(type: 'live' | 'vod' | 'series', categoryId: string | number) {
  return useQuery({
    queryKey: [api.iptv.getStreams.path, type, categoryId],
    queryFn: async () => {
      // Don't fetch if categoryId is missing/invalid
      if (!categoryId) return [];
      
      const url = buildUrl(api.iptv.getStreams.path, { type, categoryId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch streams");
      return await res.json();
    },
    enabled: !!categoryId,
    staleTime: 1000 * 60 * 2, // 2 mins
  });
}

export function useStreamInfo(type: 'live' | 'vod' | 'series', streamId: number) {
  return useQuery({
    queryKey: [api.iptv.getStreamInfo.path, type, streamId],
    queryFn: async () => {
      const url = buildUrl(api.iptv.getStreamInfo.path, { type, streamId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch info");
      return await res.json();
    },
    enabled: !!streamId,
  });
}
