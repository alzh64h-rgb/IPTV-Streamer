## Packages
framer-motion | Smooth animations for page transitions and UI elements
hls.js | HLS streaming support for the video player
date-fns | Date formatting
react-player | Robust video player component handling various formats

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'DM Sans'", "sans-serif"],
  display: ["'Outfit'", "sans-serif"],
}
