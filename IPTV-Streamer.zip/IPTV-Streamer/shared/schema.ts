import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
// Import auth models to ensure they are included in migrations
export * from "./models/auth";

// === TABLE DEFINITIONS ===

// IPTV Configurations (Xtream Codes API details)
export const iptvConfigs = pgTable("iptv_configs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(), // e.g. "Main Server"
  host: text("host").notNull(), // http://example.com:8080
  username: text("username").notNull(),
  password: text("password").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// App Settings (for UI customization, etc.)
export const appSettings = pgTable("app_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(), // e.g. "theme_color", "app_title"
  value: text("value").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Favorites (Local storage on backend for simplicity, linked to device/user if needed later)
// For now, simple favorites table. 
export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: text("user_id"), // Optional: link to Replit Auth user if logged in
  type: text("type").notNull(), // "channel", "movie", "series"
  streamId: integer("stream_id").notNull(), // ID from Xtream Codes
  name: text("name").notNull(),
  posterUrl: text("poster_url"),
  createdAt: timestamp("created_at").defaultNow(),
});


// === SCHEMAS ===

export const insertIptvConfigSchema = createInsertSchema(iptvConfigs).omit({ id: true, createdAt: true });
export const insertAppSettingsSchema = createInsertSchema(appSettings).omit({ id: true, createdAt: true });
export const insertFavoriteSchema = createInsertSchema(favorites).omit({ id: true, createdAt: true });

// === EXPLICIT API TYPES ===

export type IptvConfig = typeof iptvConfigs.$inferSelect;
export type InsertIptvConfig = z.infer<typeof insertIptvConfigSchema>;

export type AppSetting = typeof appSettings.$inferSelect;
export type InsertAppSetting = z.infer<typeof insertAppSettingsSchema>;

export type Favorite = typeof favorites.$inferSelect;
export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;

// Xtream Codes API Response Types (for typing external API responses)
export interface XtreamLoginResponse {
  user_info: {
    username: string;
    password: string;
    message: string;
    auth: number;
    status: string;
    exp_date: string;
    is_trial: string;
    active_cons: string;
    created_at: string;
    max_connections: string;
    allowed_output_formats: string[];
  };
  server_info: {
    url: string;
    port: string;
    https_port: string;
    server_protocol: string;
    rtmp_port: string;
    timezone: string;
    timestamp_now: number;
    time_now: string;
    process: boolean;
  };
}

export interface XtreamCategory {
  category_id: string;
  category_name: string;
  parent_id: number;
}

export interface XtreamStream {
  num: number;
  name: string;
  stream_type: string;
  stream_id: number;
  stream_icon: string;
  epg_channel_id: string;
  added: string;
  category_id: string;
  custom_sid: string;
  tv_archive: number;
  direct_source: string;
  tv_archive_duration: number;
}
