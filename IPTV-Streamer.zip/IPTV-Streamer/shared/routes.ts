import { z } from 'zod';
import { insertIptvConfigSchema, iptvConfigs, favorites, insertFavoriteSchema } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  })
};

export const api = {
  iptv: {
    // Config Management (Admin only)
    listConfigs: {
      method: 'GET' as const,
      path: '/api/iptv/configs',
      responses: {
        200: z.array(z.custom<typeof iptvConfigs.$inferSelect>()),
        401: errorSchemas.unauthorized
      }
    },
    createConfig: {
      method: 'POST' as const,
      path: '/api/iptv/configs',
      input: insertIptvConfigSchema,
      responses: {
        201: z.custom<typeof iptvConfigs.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized
      }
    },
    updateConfig: {
      method: 'PUT' as const,
      path: '/api/iptv/configs/:id',
      input: insertIptvConfigSchema.partial(),
      responses: {
        200: z.custom<typeof iptvConfigs.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized
      }
    },
    deleteConfig: {
      method: 'DELETE' as const,
      path: '/api/iptv/configs/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized
      }
    },
    validate: {
      method: 'POST' as const,
      path: '/api/iptv/validate',
      input: z.object({ id: z.number() }),
      responses: {
        200: z.object({ success: z.boolean(), message: z.string().optional(), info: z.any().optional() }),
        400: errorSchemas.validation
      }
    },
    
    // Public/Protected Player Routes (Proxying Xtream API to avoid CORS and hide creds)
    getCategories: {
      method: 'GET' as const,
      path: '/api/player/categories/:type', // type: 'live', 'vod', 'series'
      responses: {
        200: z.array(z.any()), // Typing this strictly is hard with dynamic APIs, using any for flexibility
        500: errorSchemas.internal
      }
    },
    getStreams: {
      method: 'GET' as const,
      path: '/api/player/streams/:type/:categoryId', // type: 'live', 'vod', 'series'
      responses: {
        200: z.array(z.any()),
        500: errorSchemas.internal
      }
    },
    // For VOD/Series Info
    getStreamInfo: {
      method: 'GET' as const,
      path: '/api/player/info/:type/:streamId', 
      responses: {
        200: z.any(),
        404: errorSchemas.notFound
      }
    }
  },
  favorites: {
    list: {
      method: 'GET' as const,
      path: '/api/favorites',
      responses: {
        200: z.array(z.custom<typeof favorites.$inferSelect>()),
      }
    },
    toggle: {
      method: 'POST' as const,
      path: '/api/favorites',
      input: insertFavoriteSchema,
      responses: {
        200: z.object({ added: z.boolean() }), // true if added, false if removed
        400: errorSchemas.validation
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
